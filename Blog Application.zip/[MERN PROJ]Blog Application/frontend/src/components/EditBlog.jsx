import React, { useEffect, useState } from 'react';
import api from '../api';
import { useNavigate, useParams } from 'react-router-dom';

function EditBlog() {
  const [form, setForm] = useState({
    title: '',
    content: '',
    image: ''
  });
  const { id } = useParams();  // Get the blog ID from URL
  const navigate = useNavigate();

  // Fetch the blog data
  useEffect(() => {
    const fetchBlog = async () => {
      try {
        const res = await api.get(`/blogs/${id}`);
        setForm(res.data);
      } catch (error) {
        console.error('Error fetching blog for edit:', error);
        alert('Failed to fetch blog for editing');
      }
    };

    fetchBlog();
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.put(`/blogs/${id}`, form);
      alert('Blog updated successfully');
      navigate('/dashboard');  // Navigate back to the dashboard after update
    } catch (error) {
      console.error('Error updating blog:', error);
      alert('Failed to update blog');
    }
  };

  return (
    <div style={{ margin: '50px' }}>
      <h2>Edit Blog</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          value={form.title}
          onChange={handleChange}
          placeholder="Title"
          style={{ marginBottom: '10px' }}
        />
        <input
          type="text"
          name="image"
          value={form.image}
          onChange={handleChange}
          placeholder="Image URL"
          style={{ marginBottom: '10px' }}
        />
        <textarea
          name="content"
          value={form.content}
          onChange={handleChange}
          placeholder="Content"
          style={{ marginBottom: '10px', width: '300px', height: '100px' }}
        />
        <button type="submit">Update Blog</button>
      </form>
    </div>
  );
}

export default EditBlog;
