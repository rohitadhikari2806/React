import React from 'react';
function BlogList() {
  return <h2>Blog List</h2>;
}
export default BlogList;
