import React, { useState } from 'react';
import api from '../api';  // API for making requests
import { useNavigate } from 'react-router-dom';

function BlogForm({ onBlogCreated }) {
  const [form, setForm] = useState({
    title: '',
    content: '',
    image: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      // Send POST request with credentials (cookies)
      const res = await api.post('/blogs', form, { withCredentials: true });

      alert(res.data.message);
      setForm({ title: '', content: '', image: '' });

      if (onBlogCreated) onBlogCreated(); // Refresh blogs list if needed
      navigate('/dashboard');  // Navigate to dashboard after blog creation
    } catch (error) {
      console.error('Blog creation error:', error);
      alert('Failed to create blog: ' + (error.response?.data?.message || 'Unknown error'));
    }
  };

  return (
    <div style={{ marginBottom: '30px' }}>
      <h3>Add Blog</h3>
      <input
        type="text"
        name="title"
        placeholder="Title"
        value={form.title}
        onChange={handleChange}
        style={{ display: 'block', marginBottom: '10px' }}
      />
      <input
        type="text"
        name="image"
        placeholder="Image URL"
        value={form.image}
        onChange={handleChange}
        style={{ display: 'block', marginBottom: '10px' }}
      />
      <textarea
        name="content"
        placeholder="Content"
        value={form.content}
        onChange={handleChange}
        style={{ display: 'block', marginBottom: '10px', width: '300px', height: '100px' }}
      />
      <button onClick={handleSubmit}>Add Blog</button>
    </div>
  );
}

export default BlogForm;
