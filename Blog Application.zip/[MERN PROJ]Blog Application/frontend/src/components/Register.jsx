import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

function Register() {
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Handle form submission
  const handleRegister = async () => {
    try {
      await api.post('/users/register', form);
      alert('User Registered Successfully');
      navigate('/login');
    } catch (error) {
      console.error('Registration Error:', error);
      alert('Registration Failed');
    }
  };
  return (
    <div style={{ margin: '50px auto', width: '300px', textAlign: 'center' }}>
      <h2>Register</h2>
      <input
        type="text"
        name="username"
        placeholder="Username"
        value={form.username}
        onChange={handleChange}
        style={{ marginBottom: '10px', width: '100%', padding: '8px' }}
      />
      <br />
      <input
        type="email"
        name="email"
        placeholder="Email"
        value={form.email}
        onChange={handleChange}
        style={{ marginBottom: '10px', width: '100%', padding: '8px' }}
      />
      <br />
      <input
        type="password"
        name="password"
        placeholder="Password"
        value={form.password}
        onChange={handleChange}
        style={{ marginBottom: '10px', width: '100%', padding: '8px' }}
      />
      <br />
      <button
        onClick={handleRegister}
        style={{ padding: '10px 20px', cursor: 'pointer' }}
      >
        Register
      </button>
    </div>
  );
}

export default Register;



// import React, { useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// function Register() {
//   const [form, setForm] = useState({
//     username: '',
//     email: '',
//     password: ''
//   });

//   const navigate = useNavigate();

//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };

//   const handleRegister = async () => {
//     try {
//       await axios.post('http://localhost:5000/api/users/register', form, {
//         withCredentials: true
//       });
//       alert('User Registered Successfully');
//       navigate('/login');
//     } catch (error) {
//       console.error(error);
//       alert('Registration Failed');
//     }
//   };

//   return (
//     <div>
//       <h2>Register</h2>
//       <input type="text" name="username" placeholder="Username" onChange={handleChange} /><br />
//       <input type="email" name="email" placeholder="Email" onChange={handleChange} /><br />
//       <input type="password" name="password" placeholder="Password" onChange={handleChange} /><br />
//       <button onClick={handleRegister}>Register</button>
//     </div>
//   );
// }

// export default Register;
